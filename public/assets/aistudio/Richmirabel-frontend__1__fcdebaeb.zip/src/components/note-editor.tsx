import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { TextStyle } from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import Highlight from "@tiptap/extension-highlight";
import TextAlign from "@tiptap/extension-text-align";
import Placeholder from "@tiptap/extension-placeholder";
import { cn } from "@/lib/cn";

export function NoteEditor({ value, onChange }: { value: string; onChange: (html: string) => void }) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
      Underline,
      TextStyle,
      Color,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      Placeholder.configure({ placeholder: "Write the lesson. Start with a heading." }),
    ],
    content: value || "<h1></h1><p></p>",
    editorProps: {
      attributes: {
        class: "min-h-[36rem] px-8 py-8 text-[1.08rem] leading-[1.8] outline-none sm:px-12",
      },
    },
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
  });

  if (!editor) return null;

  function item(active: boolean, label: string, run: () => void) {
    return (
      <button type="button" onClick={run} className={cn("min-h-9 rounded-lg px-2.5 text-sm font-medium", active ? "bg-ink text-primary-fg" : "text-ink hover:bg-paper")}>
        {label}
      </button>
    );
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-line bg-[#fbf8f2] shadow-sm">
      <div className="sticky top-0 z-10 flex flex-wrap items-center gap-1 border-b border-line bg-surface/95 px-3 py-2 backdrop-blur">
        {item(editor.isActive("heading", { level: 1 }), "Title", () => editor.chain().focus().toggleHeading({ level: 1 }).run())}
        {item(editor.isActive("heading", { level: 2 }), "Heading", () => editor.chain().focus().toggleHeading({ level: 2 }).run())}
        {item(editor.isActive("heading", { level: 3 }), "Sub", () => editor.chain().focus().toggleHeading({ level: 3 }).run())}
        <span className="mx-1 h-5 w-px bg-line" />
        {item(editor.isActive("bold"), "Bold", () => editor.chain().focus().toggleBold().run())}
        {item(editor.isActive("italic"), "Italic", () => editor.chain().focus().toggleItalic().run())}
        {item(editor.isActive("underline"), "Underline", () => editor.chain().focus().toggleUnderline().run())}
        <span className="mx-1 h-5 w-px bg-line" />
        {item(editor.isActive("bulletList"), "Bullets", () => editor.chain().focus().toggleBulletList().run())}
        {item(editor.isActive("orderedList"), "Numbers", () => editor.chain().focus().toggleOrderedList().run())}
        {item(false, "Formula", () => editor.chain().focus().insertContent("<p><strong>v = fλ</strong></p>").run())}
        <span className="mx-1 h-5 w-px bg-line" />
        {item(editor.isActive({ textAlign: "left" }), "Left", () => editor.chain().focus().setTextAlign("left").run())}
        {item(editor.isActive({ textAlign: "center" }), "Centre", () => editor.chain().focus().setTextAlign("center").run())}
        <input aria-label="Text colour" type="color" className="size-8 rounded-md border border-line" onChange={(e) => editor.chain().focus().setColor(e.target.value).run()} />
        <input aria-label="Highlight" type="color" defaultValue="#f4e4b8" className="size-8 rounded-md border border-line" onChange={(e) => editor.chain().focus().toggleHighlight({ color: e.target.value }).run()} />
        {item(false, "Undo", () => editor.chain().focus().undo().run())}
        {item(false, "Redo", () => editor.chain().focus().redo().run())}
      </div>
      <EditorContent editor={editor} />
    </div>
  );
}
