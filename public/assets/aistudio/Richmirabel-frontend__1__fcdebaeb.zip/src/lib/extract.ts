import { createServerFn } from "@tanstack/react-start";

const MAX_BYTES = 6 * 1024 * 1024;

const PROMPT = `You are turning a photographed textbook page into a clean Richmirabel lesson, like this example:

Title: Waves
Objectives:
- Define wavelength, amplitude, frequency and period
- Use the wave equation v = fλ
Sections:
1. heading "What the diagram is measuring", a short paragraph, formula "v = fλ", points for each symbol and unit
2. heading "How to read a graph in the exam", one clear paragraph

Return ONLY valid JSON:
{
  "title": "short topic title from the page",
  "objectives": ["student outcomes, from the page if listed"],
  "sections": [
    { "heading": "section title", "paragraphs": ["readable paragraphs"], "formula": "optional equation", "points": ["optional key points"], "table": [["header"], ["row"]] }
  ]
}
Rules:
- Use the page's own wording. Do not invent facts.
- Pull numbered objectives into "objectives".
- Turn callout boxes and definitions into their own sections.
- Turn tables into the "table" array. Keep units exact.
- Put important equations in "formula".
- Mark unreadable text as [unclear].
- Keep it readable: short paragraphs, clear headings, no dump of the whole page into one block.`;

export const extractNotes = createServerFn({ method: "POST" })
  .inputValidator((data: { name: string; type: string; base64: string }) => data)
  .handler(async ({ data }) => {
    const key = process.env.GEMINI_API_KEY;
    console.log("[extract] start", data.name, data.type, "key", key ? "set" : "missing");
    if (!key) {
      return { ok: false as const, reason: "not-configured", message: "GEMINI_API_KEY is not set on the server. Restart the dev server after creating .env." };
    }
    const bytes = Math.ceil((data.base64.length * 3) / 4);
    if (bytes > MAX_BYTES) {
      return { ok: false as const, reason: "too-large", message: "That file is over 6 MB. Photograph one page, not the whole chapter." };
    }
    const allowed = ["image/png", "image/jpeg", "image/webp", "application/pdf"];
    if (!allowed.includes(data.type)) {
      return { ok: false as const, reason: "unsupported", message: "Use PNG, JPG, WebP, or PDF." };
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 45_000);
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [{ parts: [{ text: PROMPT }, { inline_data: { mime_type: data.type, data: data.base64 } }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.2 },
        }),
      });
      const raw = await res.text();
      console.log("[extract] status", res.status, raw.slice(0, 300));
      if (!res.ok) {
        return { ok: false as const, reason: "provider", message: `Gemini returned ${res.status}. Check the terminal. The notes were not changed.` };
      }
      const json = JSON.parse(raw) as { candidates?: { content?: { parts?: { text?: string }[] } }[]; error?: { message?: string } };
      if (json.error?.message) return { ok: false as const, reason: "provider", message: json.error.message };
      const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("\n").trim();
      if (!text) return { ok: false as const, reason: "empty", message: "Gemini returned no text. Try a clearer photo of one page." };
      return { ok: true as const, text };
    } catch (err) {
      const aborted = err instanceof Error && err.name === "AbortError";
      console.error("[extract] failed", err);
      return { ok: false as const, reason: aborted ? "timeout" : "network", message: aborted ? "Gemini took too long. Try one page, or type the notes." : "Could not reach Gemini. Check your internet and the terminal." };
    } finally {
      clearTimeout(timer);
    }
  });
